# Shahbaz Khan Tanoli — Portfolio

A responsive, dark-theme personal portfolio for SEO and programming.

## Preview locally
Open `index.html` in a browser. No build tools or dependencies are required.

## Before publishing
1. In `index.html`, replace the empty `mailto:` in the contact button with your email address.
2. Add your real GitHub, LinkedIn, and other profile links if you want them displayed.
3. Review project descriptions and add verified project links/results only.

## Publish on GitHub Pages
1. Create a new public repository on GitHub, for example `shahbaz-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.

## Publish on Netlify
1. Sign in to Netlify and choose **Add new site → Import an existing project**.
2. Connect GitHub and select your `shahbaz-portfolio` repository.
3. Leave the build command blank and publish directory as `.` (the repository root).
4. Click **Deploy site**. Future pushes to GitHub will trigger redeploys.

This is a static site; no build command is needed.
